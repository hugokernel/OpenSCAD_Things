This is where I keep some miscellaneous Thingiverse projects and one-offs.

These are all under CC-BY-SA license.